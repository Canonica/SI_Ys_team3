﻿using UnityEngine;
using System.Collections;

public class Cell : MonoBehaviour {
    public int x;
    public int y;
    public bool isOccupied = false;
    public bool hasBonus = false;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
