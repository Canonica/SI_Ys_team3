﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class DragDrop : MonoBehaviour {
    Vector3 dist;
    float posX;
    float posY;
    public bool canMove = false;

}
