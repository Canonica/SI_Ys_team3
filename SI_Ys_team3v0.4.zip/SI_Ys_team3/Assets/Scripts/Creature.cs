﻿using UnityEngine;
using System.Collections;

public class Creature : MonoBehaviour {

    public int maxHealth = 15;
    public int currentHealth;

    public int maxMovementPoint = 3;
    public int currentMovementPoint;
    
    public int damage = 3;
    public int defense = 1;

    public int autoRange = 1;

    public bool hasAttacked = false;

    public PlayerScript player;
    public CreatureAttack creatureAtt;
    public TextMesh textMove;

    // Use this for initialization
    void Start()
    {
        player = GetComponent<PlayerScript>();
        creatureAtt = GetComponent<CreatureAttack>();
        textMove = GetComponentInChildren<TextMesh>();
        currentHealth = maxHealth;
        currentMovementPoint = maxMovementPoint;
	}
	
	void Update () {

        if(currentMovementPoint <= 0)
        {
            GetComponent<DragDrop>().canMove = false;
        }
        textMove.text = currentMovementPoint.ToString();
    }

    public void Hit(int damage)
    {
        if(damage != 0)
        {
            currentHealth -= damage * 1 / defense;
        }
        if (currentHealth <= 0)
        {
            
            Debug.Log("loose");
        }
    }
}
